# LLigMa 3.0

LLigMa 3.0 is an experimental decoder-only language model implementation with latent attention, rotary embeddings, and a routed mixture-of-experts feed-forward stack. The repository contains architecture code and a small training pipeline; it does not contain pretrained weights or evidence of reasoning performance.

## Model size

The default configuration is **not a 2B-parameter model**. With the current dimensions, its routed experts alone contribute roughly 15B parameters across the MoE layers; total size is roughly 16B parameters, while the active parameters per token are also above 2B. Actual counts can vary with weight tying and configuration. It is not suitable for training from scratch on ordinary consumer hardware. Use the deliberately small debug preset for smoke training and code experiments; it is not representative of the advertised scale.

## Install

Install a PyTorch build appropriate for your platform, then install the Python requirements:

```bash
python -m pip install -r requirements.txt
```

## Train on WikiText-2

Train and evaluate on the dataset already downloaded under `data/wikitext-2-raw-v1/`:

```bash
python scripts/train.py \
  --config configs/lligma_3_0_debug.yaml \
  --train-file data/wikitext-2-raw-v1/train-00000-of-00001.parquet \
  --validation-file data/wikitext-2-raw-v1/validation-00000-of-00001.parquet \
  --test-file data/wikitext-2-raw-v1/test-00000-of-00001.parquet \
  --output-dir outputs/lligma-wikitext2-debug \
  --sequence-length 64 \
  --max-steps 100 \
  --eval-steps 50 \
  --max-eval-examples 64 \
  --device cpu
```

This command reproduces the saved smoke checkpoint in [outputs/lligma-wikitext2-debug/README.md](outputs/lligma-wikitext2-debug/README.md). The script also supports loading a dataset directly from the Hugging Face Hub. `--max-steps` counts optimizer updates. Use `--max-train-examples` and `--max-eval-examples` to cap rows for quick experiments. WikiText-2 is small and is only appropriate for a pipeline smoke run, not for training a capable general-purpose or reasoning model. Dataset source and license information are in [data/wikitext-2-raw-v1/README.md](data/wikitext-2-raw-v1/README.md).

## Project contents

- `lligma/model/`: configuration, transformer layers, latent attention, MoE, and RoPE
- `lligma/inference/`: generation helper
- `scripts/train.py`: Hub/local dataset loading, tokenization, training, validation, and checkpoint saving
- `configs/`: default architecture and small debug training preset
- `data/wikitext-2-raw-v1/`: downloaded train, validation, and test splits

The model is randomly initialized by the training script. No pretrained checkpoint or benchmark result is included.
