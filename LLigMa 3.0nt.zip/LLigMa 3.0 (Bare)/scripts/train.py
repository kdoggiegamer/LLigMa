#!/usr/bin/env python3
"""Train LLigMa from a Hugging Face text dataset or local Parquet files."""
import argparse
import math
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import torch
import yaml
from datasets import load_dataset
from torch.utils.data import DataLoader, TensorDataset
from transformers import AutoTokenizer

from lligma.model import LLigMaConfig, LLigMaForCausalLM


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=Path("configs/lligma_3_0_2b.yaml"))
    parser.add_argument("--dataset", default="Salesforce/wikitext")
    parser.add_argument("--dataset-config", default="wikitext-2-raw-v1")
    parser.add_argument("--train-file", type=Path, help="Local Parquet/JSONL file (uses --validation-file too)")
    parser.add_argument("--validation-file", type=Path)
    parser.add_argument("--test-file", type=Path)
    parser.add_argument("--text-column", default="text")
    parser.add_argument("--tokenizer", default="gpt2", help="Hugging Face tokenizer ID or local path")
    parser.add_argument("--output-dir", type=Path, default=Path("outputs/lligma-wikitext2"))
    parser.add_argument("--sequence-length", type=int, default=256)
    parser.add_argument("--batch-size", type=int, default=1)
    parser.add_argument("--gradient-accumulation-steps", type=int, default=1)
    parser.add_argument("--max-steps", type=int, default=100)
    parser.add_argument("--learning-rate", type=float, default=5e-5)
    parser.add_argument("--weight-decay", type=float, default=0.01)
    parser.add_argument("--eval-steps", type=int, default=25)
    parser.add_argument("--max-train-examples", type=int, default=0, help="Optional cap; 0 uses all rows")
    parser.add_argument("--max-eval-examples", type=int, default=0, help="Optional cap; 0 uses all rows")
    parser.add_argument("--device", default="auto", choices=("auto", "cpu", "cuda"))
    parser.add_argument("--bf16", action="store_true")
    parser.add_argument("--seed", type=int, default=42)
    return parser.parse_args()


def load_splits(args):
    if args.train_file:
        if not args.validation_file:
            raise ValueError("--validation-file is required with --train-file")
        files = {"train": str(args.train_file), "validation": str(args.validation_file)}
        if args.test_file:
            files["test"] = str(args.test_file)
        kind = "parquet" if args.train_file.suffix == ".parquet" else "json"
        return load_dataset(kind, data_files=files)
    return load_dataset(args.dataset, args.dataset_config)


def make_blocks(split, tokenizer, column, sequence_length, limit):
    rows = split.select(range(min(limit, len(split)))) if limit else split
    token_ids = []
    texts = [text for text in rows[column] if isinstance(text, str) and text.strip()]
    for start in range(0, len(texts), 256):
        encoded = tokenizer(texts[start:start + 256], add_special_tokens=False)
        for sequence in encoded["input_ids"]:
            token_ids.extend(sequence)
    eos = tokenizer.eos_token_id
    if eos is not None:
        token_ids.append(eos)
    block_count = len(token_ids) // sequence_length
    if not block_count:
        raise ValueError(f"Split has fewer than {sequence_length} tokens after tokenization")
    packed = torch.tensor(token_ids[:block_count * sequence_length], dtype=torch.long)
    return TensorDataset(packed.view(block_count, sequence_length))


@torch.no_grad()
def evaluate(model, loader, device, max_batches=0):
    model.eval()
    total_loss = 0.0
    batches = 0
    for (input_ids,) in loader:
        input_ids = input_ids.to(device)
        loss = model(input_ids=input_ids, labels=input_ids, use_cache=False).loss
        total_loss += loss.item()
        batches += 1
        if max_batches and batches >= max_batches:
            break
    model.train()
    mean_loss = total_loss / max(batches, 1)
    return mean_loss, math.exp(min(mean_loss, 20.0))


def estimate_parameters(config):
    hidden = config.hidden_size
    attention = (
        hidden * config.q_lora_rank + config.q_lora_rank * config.num_attention_heads * (config.qk_nope_head_dim + config.qk_rope_head_dim)
        + hidden * (config.kv_lora_rank + config.qk_rope_head_dim)
        + config.kv_lora_rank * config.num_attention_heads * (config.qk_nope_head_dim + config.v_head_dim)
        + config.num_attention_heads * config.v_head_dim * hidden
    )
    dense_mlp = 3 * hidden * config.intermediate_size
    moe = config.num_experts * 3 * hidden * config.moe_intermediate_size
    moe += 3 * hidden * config.moe_intermediate_size * config.num_shared_experts
    moe += hidden * config.num_experts
    layers = sum(
        attention + (dense_mlp if index < config.first_k_dense_replace else moe)
        for index in range(config.num_hidden_layers)
    )
    embedding = config.vocab_size * hidden
    output = 0 if config.tie_word_embeddings else config.vocab_size * hidden
    return layers + embedding + output


def main():
    args = parse_args()
    if args.max_steps < 1 or args.sequence_length < 2:
        raise ValueError("--max-steps must be positive and --sequence-length at least 2")
    if args.device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is unavailable")
    device = torch.device("cuda" if args.device == "cuda" or (args.device == "auto" and torch.cuda.is_available()) else "cpu")
    if args.bf16 and (device.type != "cuda" or not torch.cuda.is_bf16_supported()):
        raise RuntimeError("--bf16 requires a CUDA device with bfloat16 support")
    torch.manual_seed(args.seed)

    tokenizer = AutoTokenizer.from_pretrained(args.tokenizer, use_fast=True)
    if tokenizer.eos_token_id is None:
        raise ValueError("The tokenizer must define an EOS token")
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    splits = load_splits(args)
    if "validation" not in splits:
        raise ValueError("Dataset must provide a validation split")

    with args.config.open(encoding="utf-8") as handle:
        config_values = yaml.safe_load(handle) or {}
    config_values.pop("model_type", None)
    config_values["vocab_size"] = len(tokenizer)
    config_values["bos_token_id"] = tokenizer.bos_token_id or tokenizer.eos_token_id
    config_values["eos_token_id"] = tokenizer.eos_token_id
    config_values["pad_token_id"] = tokenizer.pad_token_id
    config_values["max_position_embeddings"] = max(args.sequence_length, config_values.get("max_position_embeddings", args.sequence_length))
    config_values["use_cache"] = False
    config = LLigMaConfig(**config_values)
    estimate = estimate_parameters(config)
    print(f"Device: {device}; estimated model parameters: {estimate:,} ({estimate / 1e9:.2f}B)")
    if estimate > 2_000_000_000:
        raise RuntimeError("Configured model exceeds 2B parameters; refusing to allocate it. Use a smaller config for this machine.")
    model = LLigMaForCausalLM(config).to(device)
    actual = sum(parameter.numel() for parameter in model.parameters())
    print(f"Instantiated parameters: {actual:,}")
    if args.bf16:
        model.to(dtype=torch.bfloat16)

    train_data = make_blocks(splits["train"], tokenizer, args.text_column, args.sequence_length, args.max_train_examples)
    val_data = make_blocks(splits["validation"], tokenizer, args.text_column, args.sequence_length, args.max_eval_examples)
    train_loader = DataLoader(train_data, batch_size=args.batch_size, shuffle=True, drop_last=True)
    val_loader = DataLoader(val_data, batch_size=args.batch_size)
    if not len(train_loader):
        raise ValueError("No complete training batch; lower batch size or sequence length")

    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    model.train()
    optimizer_steps = 0
    micro_step = 0
    while optimizer_steps < args.max_steps:
        for (input_ids,) in train_loader:
            input_ids = input_ids.to(device)
            loss = model(input_ids=input_ids, labels=input_ids, use_cache=False).loss
            (loss / args.gradient_accumulation_steps).backward()
            micro_step += 1
            if micro_step % args.gradient_accumulation_steps == 0:
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                optimizer.step()
                optimizer.zero_grad(set_to_none=True)
                optimizer_steps += 1
                if optimizer_steps == 1 or optimizer_steps % 10 == 0:
                    print(f"step {optimizer_steps}/{args.max_steps} train_loss={loss.item():.4f}")
                if args.eval_steps and optimizer_steps % args.eval_steps == 0:
                    val_loss, ppl = evaluate(model, val_loader, device)
                    print(f"validation step={optimizer_steps} loss={val_loss:.4f} perplexity={ppl:.2f}")
            if optimizer_steps >= args.max_steps:
                break

    args.output_dir.mkdir(parents=True, exist_ok=True)
    model.save_pretrained(args.output_dir)
    tokenizer.save_pretrained(args.output_dir)
    if "test" in splits:
        test_data = make_blocks(splits["test"], tokenizer, args.text_column, args.sequence_length, args.max_eval_examples)
        test_loss, test_ppl = evaluate(model, DataLoader(test_data, batch_size=args.batch_size), device)
        print(f"test loss={test_loss:.4f} perplexity={test_ppl:.2f}")
    print(f"Saved model and tokenizer to {args.output_dir}")


if __name__ == "__main__":
    main()
