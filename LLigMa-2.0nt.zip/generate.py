import argparse
import tensorflow as tf

from config import GPTConfig
from model import LLigMaGPT
from tokenizer import BPETokenizer


def load_model():
    config = GPTConfig()
    model = LLigMaGPT(config)

    model(
        tf.zeros(
            (1, config.block_size),
            dtype=tf.int32,
        )
    )

    latest = tf.train.latest_checkpoint("checkpoints")

    if latest is None:
        raise RuntimeError(
            "No checkpoint found in checkpoints/"
        )

    print("Loading:", latest)

    checkpoint = tf.train.Checkpoint(
        model=model
    )

    checkpoint.restore(
        latest
    ).expect_partial()

    return model, config


def generate(
    model,
    config,
    tokenizer,
    prompt,
    max_new_tokens=200,
    temperature=0.8,
    top_k=40,
):
    tokens = tokenizer.encode(prompt)

    for _ in range(max_new_tokens):
        context = tokens[-config.block_size:]

        x = tf.convert_to_tensor(
            [context],
            dtype=tf.int32,
        )

        logits = model(
            x,
            training=False,
        )[0, -1]

        logits = tf.cast(
            logits,
            tf.float32,
        )

        logits = logits / max(
            temperature,
            1e-5,
        )

        if top_k is not None:
            values, _ = tf.math.top_k(
                logits,
                k=min(
                    top_k,
                    config.vocab_size,
                ),
            )

            threshold = values[-1]

            logits = tf.where(
                logits < threshold,
                tf.cast(-1e10, logits.dtype),
                logits,
            )

        next_token = tf.random.categorical(
            tf.expand_dims(logits, 0),
            1,
        )[0, 0]

        tokens.append(
            int(next_token.numpy())
        )

    return tokenizer.decode(tokens)


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "prompt",
        nargs="?",
        default="Once upon a time",
    )

    parser.add_argument(
        "--tokens",
        type=int,
        default=200,
    )

    parser.add_argument(
        "--temperature",
        type=float,
        default=0.8,
    )

    parser.add_argument(
        "--top-k",
        type=int,
        default=40,
    )

    args = parser.parse_args()

    tokenizer = BPETokenizer(
        "data/processed/tokenizer.json"
    )

    model, config = load_model()

    output = generate(
        model,
        config,
        tokenizer,
        args.prompt,
        args.tokens,
        args.temperature,
        args.top_k,
    )

    print()
    print("========== LLigMa 2.0 ==========")
    print(output)
    print("=================================")


if __name__ == "__main__":
    main()
