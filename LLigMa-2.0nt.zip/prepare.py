from pathlib import Path
import numpy as np
from tokenizer import BPETokenizer

RAW_FILE = Path("data/raw/tinystories_100mb.txt")
OUT_DIR = Path("data/processed")
TOKENIZER_FILE = OUT_DIR / "tokenizer.json"
TOKEN_FILE = OUT_DIR / "tokens.bin"

def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    if not RAW_FILE.exists():
        raise FileNotFoundError(RAW_FILE)

    print("Training BPE tokenizer...")
    tokenizer = BPETokenizer(TOKENIZER_FILE)
    tokenizer.train(RAW_FILE)
    print(f"Vocabulary size: {tokenizer.vocab_size:,}")

    print("Tokenizing corpus...")
    text = RAW_FILE.read_text(encoding="utf-8", errors="ignore")
    ids = tokenizer.encode(text)

    if tokenizer.vocab_size <= 65535:
        arr = np.asarray(ids, dtype=np.uint16)
    else:
        arr = np.asarray(ids, dtype=np.uint32)

    arr.tofile(TOKEN_FILE)

    print(f"Characters: {len(text):,}")
    print(f"Tokens:     {len(ids):,}")
    print(f"Saved:      {TOKEN_FILE}")

if __name__ == "__main__":
    main()
