from pathlib import Path
import numpy as np
from datasets import load_dataset
from tokenizers import Tokenizer, models, trainers, pre_tokenizers, decoders

RAW = Path("data/raw/fineweb_stream.txt")
OUT = Path("data/processed")
TOK = OUT / "tokenizer.json"
SHARD_DIR = OUT / "shards"

TARGET_BYTES = 4_000_000_000
VOCAB = 32000
CHUNK_BYTES = 8 * 1024 * 1024
TOKENS_PER_SHARD = 10_000_000

RAW.parent.mkdir(parents=True, exist_ok=True)
OUT.mkdir(parents=True, exist_ok=True)
SHARD_DIR.mkdir(parents=True, exist_ok=True)

# ------------------------------------------------------------
# 1. Collect FineWeb if corpus doesn't already exist.
# ------------------------------------------------------------
if not RAW.exists() or RAW.stat().st_size < TARGET_BYTES:
    print("Streaming FineWeb...")
    ds = load_dataset(
        "HuggingFaceFW/fineweb",
        name="sample-10BT",
        split="train",
        streaming=True,
    )

    written = 0

    with RAW.open("w", encoding="utf-8") as f:
        for row in ds:
            text = row["text"].strip()
            if not text:
                continue

            chunk = text + "\n\n"
            b = len(chunk.encode("utf-8"))

            if written + b > TARGET_BYTES:
                break

            f.write(chunk)
            written += b

            if written // 100_000_000 != (written - b) // 100_000_000:
                print(f"Collected {written / 1e9:.2f} GB")

    print(f"Raw corpus: {written / 1e9:.2f} GB")
else:
    print(f"Using existing corpus: {RAW.stat().st_size / 1e9:.2f} GB")

# ------------------------------------------------------------
# 2. Train BPE tokenizer only if it doesn't exist.
# ------------------------------------------------------------
if TOK.exists():
    print("Loading existing tokenizer...")
    tokenizer = Tokenizer.from_file(str(TOK))
else:
    print("Training BPE tokenizer...")

    tokenizer = Tokenizer(
        models.BPE(unk_token="[UNK]")
    )

    tokenizer.pre_tokenizer = pre_tokenizers.ByteLevel(
        add_prefix_space=False
    )

    trainer = trainers.BpeTrainer(
        vocab_size=VOCAB,
        min_frequency=2,
        special_tokens=[
            "[UNK]",
            "[BOS]",
            "[EOS]",
        ],
    )

    tokenizer.train([str(RAW)], trainer)
    tokenizer.decoder = decoders.ByteLevel()
    tokenizer.save(str(TOK))

    print(
        f"Tokenizer vocabulary: "
        f"{tokenizer.get_vocab_size():,}"
    )

# ------------------------------------------------------------
# 3. Delete incomplete old shards.
# ------------------------------------------------------------
for shard in SHARD_DIR.glob("tokens_*.bin"):
    shard.unlink()

# ------------------------------------------------------------
# 4. Stream tokenization in chunks.
# ------------------------------------------------------------
print("Streaming tokenization...")

shard_index = 0
token_buffer = []
total_tokens = 0

def flush_shard():
    global shard_index, token_buffer, total_tokens

    if not token_buffer:
        return

    arr = np.asarray(
        token_buffer,
        dtype=np.uint16,
    )

    path = SHARD_DIR / f"tokens_{shard_index:05d}.bin"
    arr.tofile(path)

    total_tokens += len(arr)

    print(
        f"Shard {shard_index:05d}: "
        f"{len(arr):,} tokens | "
        f"total {total_tokens:,}"
    )

    shard_index += 1
    token_buffer = []

with RAW.open(
    "r",
    encoding="utf-8",
    errors="ignore",
) as f:

    while True:
        text = f.read(CHUNK_BYTES)

        if not text:
            break

        ids = tokenizer.encode(text).ids
        token_buffer.extend(ids)

        while len(token_buffer) >= TOKENS_PER_SHARD:
            shard = token_buffer[:TOKENS_PER_SHARD]
            token_buffer = token_buffer[TOKENS_PER_SHARD:]

            arr = np.asarray(
                shard,
                dtype=np.uint16,
            )

            path = (
                SHARD_DIR
                / f"tokens_{shard_index:05d}.bin"
            )

            arr.tofile(path)

            total_tokens += len(arr)

            print(
                f"Shard {shard_index:05d}: "
                f"{len(arr):,} tokens | "
                f"total {total_tokens:,}"
            )

            shard_index += 1

flush_shard()

print()
print("======================================")
print("Corpus tokenization complete.")
print(f"Total tokens: {total_tokens:,}")
print(f"Shards:       {shard_index:,}")
print(f"Output:       {SHARD_DIR}")
print("======================================")
