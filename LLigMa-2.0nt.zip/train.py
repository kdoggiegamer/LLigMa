import os
import time
import math
import tensorflow as tf

from config import GPTConfig
from dataset import GPTDataset
from model import LLigMaGPT

os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "1")

ACCUM_STEPS = 16
WARMUP_STEPS = 2000


def configure_gpu():
    gpus = tf.config.list_physical_devices("GPU")

    if not gpus:
        print("WARNING: No GPU detected. Using CPU.")
        return False

    for gpu in gpus:
        try:
            tf.config.experimental.set_memory_growth(gpu, True)
        except RuntimeError:
            pass

    tf.keras.mixed_precision.set_global_policy("mixed_float16")

    print(f"GPU(s): {len(gpus)}")
    for gpu in gpus:
        print(f"  {gpu}")
    print("Mixed precision: mixed_float16")

    return True


def loss_function(targets, logits):
    logits = tf.cast(logits, tf.float32)

    loss = tf.keras.losses.sparse_categorical_crossentropy(
        targets,
        logits,
        from_logits=True,
    )

    return tf.reduce_mean(loss)


def lr_schedule(step, max_steps, base_lr):
    step = tf.cast(step, tf.float32)
    max_steps = tf.cast(max_steps, tf.float32)
    warmup = tf.cast(WARMUP_STEPS, tf.float32)

    warmup_lr = base_lr * (step + 1.0) / warmup

    progress = (
        tf.maximum(step - warmup, 0.0)
        / tf.maximum(max_steps - warmup, 1.0)
    )

    cosine_lr = (
        0.1
        + 0.9 * 0.5 * (
            1.0 + tf.cos(math.pi * progress)
        )
    ) * base_lr

    return tf.where(
        step < warmup,
        warmup_lr,
        cosine_lr,
    )


def main():
    using_gpu = configure_gpu()

    config = GPTConfig()

    dataset = GPTDataset(
        "data/processed/shards",
        config.block_size,
    )

    model = LLigMaGPT(config)

    model(
        tf.zeros(
            (1, config.block_size),
            dtype=tf.int32,
        )
    )

    print(f"Parameters: {model.count_params():,}")
    print(f"Context: {config.block_size}")
    print(f"Gradient accumulation: {ACCUM_STEPS}")
    print(f"Effective batch size: {ACCUM_STEPS}")

    optimizer = tf.keras.optimizers.AdamW(
        learning_rate=config.learning_rate,
        weight_decay=config.weight_decay,
    )

    checkpoint = tf.train.Checkpoint(
        model=model,
        optimizer=optimizer,
    )

    manager = tf.train.CheckpointManager(
        checkpoint,
        "checkpoints",
        max_to_keep=10,
    )

    print("Starting completely from scratch.")

    @tf.function
    def train_accumulated():
        grad_accums = [
            tf.zeros_like(v)
            for v in model.trainable_variables
        ]

        total_loss = tf.constant(0.0, tf.float32)

        for _ in tf.range(ACCUM_STEPS):
            x, y = dataset.sample_batch(
                config.batch_size
            )

            with tf.GradientTape() as tape:
                logits = model(
                    x,
                    training=True,
                )
                loss = loss_function(y, logits)
                scaled_loss = loss / ACCUM_STEPS

            grads = tape.gradient(
                scaled_loss,
                model.trainable_variables,
            )

            grad_accums = [
                a + tf.cast(g, a.dtype)
                for a, g in zip(grad_accums, grads)
            ]

            total_loss += loss

        grad_accums, _ = tf.clip_by_global_norm(
            grad_accums,
            config.grad_clip,
        )

        optimizer.apply_gradients(
            zip(
                grad_accums,
                model.trainable_variables,
            )
        )

        return total_loss / ACCUM_STEPS

    print()
    print("========== LLigMa 2.0 TRAINING ==========")

    start = time.time()
    seen_tokens = 0

    for step in range(config.max_steps):
        lr = lr_schedule(
            step,
            config.max_steps,
            config.learning_rate,
        )

        optimizer.learning_rate.assign(lr)

        loss = train_accumulated()

        seen_tokens += (
            ACCUM_STEPS
            * config.batch_size
            * config.block_size
        )

        if step % 10 == 0:
            elapsed = time.time() - start
            tok_s = seen_tokens / max(elapsed, 1e-6)

            print(
                f"step {step:6d} | "
                f"loss {float(loss):.4f} | "
                f"lr {float(lr):.2e} | "
                f"{tok_s:,.0f} tok/s | "
                f"{'GPU' if using_gpu else 'CPU'}"
            )

        if (
            step > 0
            and step % config.checkpoint_interval == 0
        ):
            path = manager.save()
            print("Checkpoint saved:", path)

    print()
    print("Final checkpoint:", manager.save())
    print("Training complete.")


if __name__ == "__main__":
    main()
