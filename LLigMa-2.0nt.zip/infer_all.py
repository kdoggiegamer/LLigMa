import argparse
import re
from pathlib import Path

import tensorflow as tf

from config import GPTConfig
from model import LLigMaGPT
from tokenizer import BPETokenizer


def checkpoint_number(path: Path):
    match = re.search(r"ckpt-(\d+)$", path.name)
    return int(match.group(1)) if match else -1


def load_model(config, checkpoint_path):
    model = LLigMaGPT(config)
    model(tf.zeros((1, config.block_size), dtype=tf.int32))

    checkpoint = tf.train.Checkpoint(model=model)
    checkpoint.restore(str(checkpoint_path)).expect_partial()

    return model


def generate(
    model,
    config,
    tokenizer,
    prompt,
    max_new_tokens,
    temperature,
    top_k,
):
    tokens = tokenizer.encode(prompt)

    for _ in range(max_new_tokens):
        context = tokens[-config.block_size:]

        x = tf.convert_to_tensor(
            [context],
            dtype=tf.int32,
        )

        logits = model(
            x,
            training=False,
        )[0, -1]

        logits = tf.cast(logits, tf.float32)
        logits = logits / max(temperature, 1e-5)

        if top_k is not None:
            values = tf.math.top_k(
                logits,
                k=min(top_k, config.vocab_size),
            ).values

            threshold = values[-1]

            logits = tf.where(
                logits < threshold,
                tf.constant(-1e10, dtype=tf.float32),
                logits,
            )

        next_token = tf.random.categorical(
            tf.expand_dims(logits, 0),
            1,
        )[0, 0]

        tokens.append(int(next_token.numpy()))

    return tokenizer.decode(tokens)


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--prompt",
        default="Once upon a time",
    )

    parser.add_argument(
        "--tokens",
        type=int,
        default=300,
    )

    parser.add_argument(
        "--temperature",
        type=float,
        default=0.8,
    )

    parser.add_argument(
        "--top-k",
        type=int,
        default=40,
    )

    parser.add_argument(
        "--start",
        type=int,
        default=1,
    )

    parser.add_argument(
        "--end",
        type=int,
        default=100,
    )

    args = parser.parse_args()

    config = GPTConfig()

    tokenizer = BPETokenizer(
        "data/processed/tokenizer.json"
    )

    checkpoint_dir = Path("checkpoints")

    checkpoint_files = []

    for i in range(args.start, args.end + 1):
        path = checkpoint_dir / f"ckpt-{i}.index"

        if path.exists():
            checkpoint_files.append(
                checkpoint_dir / f"ckpt-{i}"
            )

    if not checkpoint_files:
        raise RuntimeError(
            "No requested checkpoints found."
        )

    checkpoint_files.sort(
        key=checkpoint_number
    )

    output_path = Path(
        f"inference_{args.start:03d}_{args.end:03d}.txt"
    )

    with output_path.open(
        "w",
        encoding="utf-8",
    ) as out:

        for idx, checkpoint_path in enumerate(
            checkpoint_files,
            start=1,
        ):
            number = checkpoint_number(
                checkpoint_path
            )

            print(
                f"[{idx}/{len(checkpoint_files)}] "
                f"ckpt-{number}"
            )

            model = load_model(
                config,
                checkpoint_path,
            )

            text = generate(
                model,
                config,
                tokenizer,
                args.prompt,
                args.tokens,
                args.temperature,
                args.top_k,
            )

            out.write(
                f"\n{'=' * 80}\n"
            )
            out.write(
                f"CHECKPOINT {number}\n"
            )
            out.write(
                f"{'=' * 80}\n\n"
            )
            out.write(text)
            out.write("\n\n")

            del model

        print()
        print(
            f"Saved all generations to: {output_path}"
        )


if __name__ == "__main__":
    main()
