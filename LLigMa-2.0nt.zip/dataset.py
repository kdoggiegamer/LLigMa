from pathlib import Path
import random
import numpy as np
import tensorflow as tf


class GPTDataset:
    def __init__(self, shard_dir: str, block_size: int):
        self.block_size = block_size

        self.shards = sorted(
            Path(shard_dir).glob("tokens_*.bin")
        )

        if not self.shards:
            raise FileNotFoundError(
                f"No token shards found in {shard_dir}"
            )

        self.data = [
            np.memmap(
                path,
                dtype=np.uint16,
                mode="r",
            )
            for path in self.shards
        ]

        self.lengths = [len(x) for x in self.data]

        usable = [
            n > block_size + 1
            for n in self.lengths
        ]

        if not all(usable):
            raise ValueError(
                "One or more shards are too small."
            )

        self.total_tokens = sum(self.lengths)

        print(
            f"Loaded {len(self.shards):,} shards | "
            f"{self.total_tokens:,} tokens"
        )

    def sample_batch(self, batch_size: int):
        xs = []
        ys = []

        for _ in range(batch_size):
            shard_id = random.randrange(len(self.data))
            data = self.data[shard_id]

            start = random.randint(
                0,
                len(data) - self.block_size - 1,
            )

            xs.append(
                np.asarray(
                    data[
                        start:
                        start + self.block_size
                    ],
                    dtype=np.int32,
                )
            )

            ys.append(
                np.asarray(
                    data[
                        start + 1:
                        start + self.block_size + 1
                    ],
                    dtype=np.int32,
                )
            )

        return (
            tf.convert_to_tensor(
                np.stack(xs),
                dtype=tf.int32,
            ),
            tf.convert_to_tensor(
                np.stack(ys),
                dtype=tf.int32,
            ),
        )
