#!/usr/bin/env bash
set -euo pipefail

mkdir -p data/raw data/processed checkpoints logs

cat > config.py <<'PY'
from dataclasses import dataclass

@dataclass
class GPTConfig:
    vocab_size: int = 256
    block_size: int = 512
    n_layer: int = 8
    n_head: int = 8
    n_embd: int = 512
    dropout: float = 0.0
    batch_size: int = 1
    learning_rate: float = 3e-4
    weight_decay: float = 0.1
    grad_clip: float = 1.0
    max_steps: int = 10_000
    checkpoint_interval: int = 500

    @property
    def head_size(self):
        if self.n_embd % self.n_head != 0:
            raise ValueError("n_embd must be divisible by n_head")
        return self.n_embd // self.n_head
PY

cat > tokenizer.py <<'PY'
from pathlib import Path

class ByteTokenizer:
    vocab_size = 256

    def encode(self, text: str) -> list[int]:
        return list(text.encode("utf-8"))

    def decode(self, tokens: list[int]) -> str:
        return bytes(int(t) % 256 for t in tokens).decode("utf-8", errors="replace")

    def encode_file(self, path: str | Path) -> list[int]:
        text = Path(path).read_text(encoding="utf-8", errors="ignore")
        return self.encode(text)

    def save(self, path: str | Path):
        Path(path).write_text(
            "LLigMa 2.0 byte-level tokenizer\nvocab_size=256\n",
            encoding="utf-8",
        )
PY

cat > prepare.py <<'PY'
from pathlib import Path
import numpy as np
from tokenizer import ByteTokenizer

RAW_DIR = Path("data/raw")
OUTPUT_DIR = Path("data/processed")
TOKEN_FILE = OUTPUT_DIR / "tokens.bin"
TOKENIZER_FILE = OUTPUT_DIR / "tokenizer.txt"

def main():
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    files = sorted(RAW_DIR.rglob("*.txt"))
    if not files:
        raise RuntimeError("No .txt files found in data/raw/")

    tokenizer = ByteTokenizer()
    all_tokens = []

    for path in files:
        print(f"Reading: {path}")
        text = path.read_text(encoding="utf-8", errors="ignore")
        all_tokens.extend(tokenizer.encode(text))

    tokens = np.asarray(all_tokens, dtype=np.uint8)
    tokens.tofile(TOKEN_FILE)
    tokenizer.save(TOKENIZER_FILE)

    print(f"\nFiles: {len(files):,}")
    print(f"Tokens: {len(tokens):,}")
    print(f"Saved: {TOKEN_FILE}")

if __name__ == "__main__":
    main()
PY

cat > dataset.py <<'PY'
from pathlib import Path
import numpy as np
import tensorflow as tf

class GPTDataset:
    def __init__(self, token_file: str, block_size: int):
        self.block_size = block_size
        path = Path(token_file)

        if not path.exists():
            raise FileNotFoundError(f"Token file not found: {path}")

        self.data = np.memmap(path, dtype=np.uint8, mode="r")

        if len(self.data) <= block_size:
            raise ValueError("Dataset is smaller than block_size.")

    def sample_batch(self, batch_size: int):
        max_start = len(self.data) - self.block_size - 1
        starts = np.random.randint(0, max_start + 1, size=batch_size)

        x = np.stack([
            self.data[s:s+self.block_size] for s in starts
        ])
        y = np.stack([
            self.data[s+1:s+self.block_size+1] for s in starts
        ])

        return (
            tf.convert_to_tensor(x, dtype=tf.int32),
            tf.convert_to_tensor(y, dtype=tf.int32),
        )
PY

cat > model.py <<'PY'
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from config import GPTConfig

class CausalSelfAttention(layers.Layer):
    def __init__(self, config):
        super().__init__()
        self.n_head = config.n_head
        self.n_embd = config.n_embd
        self.head_size = config.head_size

        self.qkv = layers.Dense(3 * config.n_embd, use_bias=False)
        self.proj = layers.Dense(config.n_embd, use_bias=False)
        self.attn_dropout = layers.Dropout(config.dropout)
        self.resid_dropout = layers.Dropout(config.dropout)

        mask = tf.linalg.band_part(
            tf.ones((config.block_size, config.block_size)), -1, 0
        )
        self.causal_mask = tf.reshape(
            mask, (1, 1, config.block_size, config.block_size)
        )

    def call(self, x, training=False):
        batch_size = tf.shape(x)[0]
        seq_len = tf.shape(x)[1]

        qkv = self.qkv(x)
        q, k, v = tf.split(qkv, 3, axis=-1)

        q = tf.reshape(q, [batch_size, seq_len, self.n_head, self.head_size])
        k = tf.reshape(k, [batch_size, seq_len, self.n_head, self.head_size])
        v = tf.reshape(v, [batch_size, seq_len, self.n_head, self.head_size])

        q = tf.transpose(q, [0, 2, 1, 3])
        k = tf.transpose(k, [0, 2, 1, 3])
        v = tf.transpose(v, [0, 2, 1, 3])

        scale = tf.cast(self.head_size, x.dtype) ** -0.5
        scores = tf.matmul(q, k, transpose_b=True) * scale

        mask = self.causal_mask[:, :, :seq_len, :seq_len]
        negative = tf.cast(-1e4, scores.dtype)
        scores = tf.where(mask == 1, scores, negative)

        weights = tf.nn.softmax(scores, axis=-1)
        weights = self.attn_dropout(weights, training=training)

        y = tf.matmul(weights, v)
        y = tf.transpose(y, [0, 2, 1, 3])
        y = tf.reshape(y, [batch_size, seq_len, self.n_embd])

        return self.resid_dropout(self.proj(y), training=training)

class MLP(layers.Layer):
    def __init__(self, config):
        super().__init__()
        self.fc = layers.Dense(4 * config.n_embd)
        self.proj = layers.Dense(config.n_embd)
        self.dropout = layers.Dropout(config.dropout)

    def call(self, x, training=False):
        x = tf.nn.gelu(self.fc(x))
        x = self.proj(x)
        return self.dropout(x, training=training)

class GPTBlock(layers.Layer):
    def __init__(self, config):
        super().__init__()
        self.ln1 = layers.LayerNormalization(epsilon=1e-5)
        self.attention = CausalSelfAttention(config)
        self.ln2 = layers.LayerNormalization(epsilon=1e-5)
        self.mlp = MLP(config)

    def call(self, x, training=False):
        x = x + self.attention(self.ln1(x), training=training)
        x = x + self.mlp(self.ln2(x), training=training)
        return x

class LLigMaGPT(keras.Model):
    def __init__(self, config):
        super().__init__()
        self.config = config

        self.token_embedding = layers.Embedding(
            config.vocab_size, config.n_embd
        )
        self.position_embedding = layers.Embedding(
            config.block_size, config.n_embd
        )
        self.dropout = layers.Dropout(config.dropout)

        self.blocks = [GPTBlock(config) for _ in range(config.n_layer)]
        self.ln_f = layers.LayerNormalization(epsilon=1e-5)
        self.lm_head = layers.Dense(config.vocab_size, use_bias=False)

    def call(self, idx, training=False):
        seq_len = tf.shape(idx)[1]
        positions = tf.range(seq_len)

        x = (
            self.token_embedding(idx)
            + self.position_embedding(positions)
        )

        x = self.dropout(x, training=training)

        for block in self.blocks:
            x = block(x, training=training)

        x = self.ln_f(x)
        return self.lm_head(x)
PY

cat > test_model.py <<'PY'
import tensorflow as tf
from config import GPTConfig
from model import LLigMaGPT

config = GPTConfig()
model = LLigMaGPT(config)

x = tf.random.uniform(
    (1, config.block_size),
    minval=0,
    maxval=config.vocab_size,
    dtype=tf.int32,
)

logits = model(x)

print("\n========== LLigMa 2.0 ==========")
print("Input:      ", x.shape)
print("Output:     ", logits.shape)
print("Parameters: ", f"{model.count_params():,}")
print("GPU:        ", tf.config.list_physical_devices("GPU"))
print("================================\n")
PY

cat > train.py <<'PY'
import os
import time
import tensorflow as tf

from config import GPTConfig
from dataset import GPTDataset
from model import LLigMaGPT

os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "1")

def configure_gpu():
    gpus = tf.config.list_physical_devices("GPU")
    if not gpus:
        print("No GPU detected — using CPU.")
        return

    print(f"Found {len(gpus)} GPU(s).")
    for gpu in gpus:
        try:
            tf.config.experimental.set_memory_growth(gpu, True)
        except RuntimeError:
            pass

def loss_function(targets, logits):
    loss = tf.keras.losses.sparse_categorical_crossentropy(
        targets, logits, from_logits=True
    )
    return tf.reduce_mean(loss)

def main():
    configure_gpu()
    config = GPTConfig()

    dataset = GPTDataset(
        "data/processed/tokens.bin",
        config.block_size,
    )

    model = LLigMaGPT(config)

    dummy = tf.zeros((1, config.block_size), dtype=tf.int32)
    model(dummy)

    print(f"Parameters: {model.count_params():,}")

    optimizer = tf.keras.optimizers.AdamW(
        learning_rate=config.learning_rate,
        weight_decay=config.weight_decay,
    )

    checkpoint = tf.train.Checkpoint(
        model=model,
        optimizer=optimizer,
    )

    manager = tf.train.CheckpointManager(
        checkpoint,
        "checkpoints",
        max_to_keep=5,
    )

    if manager.latest_checkpoint:
        print("Restoring:", manager.latest_checkpoint)
        checkpoint.restore(manager.latest_checkpoint)
    else:
        print("Starting from scratch.")

    start_time = time.time()

    for step in range(config.max_steps):
        x, y = dataset.sample_batch(config.batch_size)

        with tf.GradientTape() as tape:
            logits = model(x, training=True)
            loss = loss_function(y, logits)

        gradients = tape.gradient(loss, model.trainable_variables)
        gradients, _ = tf.clip_by_global_norm(
            gradients, config.grad_clip
        )

        optimizer.apply_gradients(
            zip(gradients, model.trainable_variables)
        )

        if step % 10 == 0:
            elapsed = time.time() - start_time
            tokens = (step + 1) * config.batch_size * config.block_size
            tok_s = tokens / max(elapsed, 1e-6)

            print(
                f"step {step:6d} | "
                f"loss {loss.numpy():.4f} | "
                f"{tok_s:,.0f} tok/s"
            )

        if step > 0 and step % config.checkpoint_interval == 0:
            path = manager.save()
            print("Checkpoint saved:", path)

    print("Final checkpoint:", manager.save())

if __name__ == "__main__":
    main()
PY

cat > generate.py <<'PY'
import argparse
import tensorflow as tf

from config import GPTConfig
from model import LLigMaGPT
from tokenizer import ByteTokenizer

def load_model():
    config = GPTConfig()
    model = LLigMaGPT(config)

    model(tf.zeros((1, config.block_size), dtype=tf.int32))

    latest = tf.train.latest_checkpoint("checkpoints")
    if latest is None:
        raise RuntimeError("No checkpoint found in checkpoints/")

    print("Loading:", latest)

    checkpoint = tf.train.Checkpoint(model=model)
    checkpoint.restore(latest).expect_partial()

    return model, config

def generate(model, config, tokenizer, prompt,
             max_new_tokens=200, temperature=0.8, top_k=40):

    tokens = tokenizer.encode(prompt)

    for _ in range(max_new_tokens):
        context = tokens[-config.block_size:]

        x = tf.convert_to_tensor([context], dtype=tf.int32)
        logits = model(x, training=False)[0, -1]
        logits = logits / temperature

        if top_k is not None:
            values, _ = tf.math.top_k(
                logits,
                k=min(top_k, config.vocab_size),
            )
            threshold = values[-1]
            logits = tf.where(
                logits < threshold,
                tf.cast(-1e10, logits.dtype),
                logits,
            )

        next_token = tf.random.categorical(
            tf.expand_dims(logits, 0),
            1,
        )[0, 0]

        tokens.append(int(next_token.numpy()))

    return tokenizer.decode(tokens)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("prompt", nargs="?", default="Hello, my name is")
    parser.add_argument("--tokens", type=int, default=200)
    parser.add_argument("--temperature", type=float, default=0.8)
    parser.add_argument("--top-k", type=int, default=40)
    args = parser.parse_args()

    tokenizer = ByteTokenizer()
    model, config = load_model()

    print(
        generate(
            model,
            config,
            tokenizer,
            args.prompt,
            args.tokens,
            args.temperature,
            args.top_k,
        )
    )

if __name__ == "__main__":
    main()
PY

cat > requirements.txt <<'REQ'
tensorflow==2.21.0
numpy
REQ

cat > data/raw/train.txt <<'TXT'
LLigMa is a language model created from scratch.

LLigMa learns by predicting the next token in a sequence.

A GPT model reads tokens and learns statistical patterns in text.

The transformer uses causal self attention so that each token can only see previous tokens.

LLigMa 2.0 is a decoder only GPT architecture implemented using TensorFlow and Keras.

The model is trained with next token prediction and gradient descent.

This is the first experimental training corpus for LLigMa 2.0.
TXT

python -m pip install -r requirements.txt
python prepare.py
python test_model.py

echo
echo "=========================================="
echo " LLigMa 2.0 PROJECT CREATED SUCCESSFULLY "
echo "=========================================="
echo
echo "Test training:"
echo "  python train.py"
echo
echo "Generate after training:"
echo '  python generate.py "LLigMa is"'
