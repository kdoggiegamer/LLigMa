import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from config import GPTConfig

class CausalSelfAttention(layers.Layer):
    def __init__(self, config):
        super().__init__()
        self.n_head = config.n_head
        self.n_embd = config.n_embd
        self.head_size = config.head_size

        self.qkv = layers.Dense(3 * config.n_embd, use_bias=False)
        self.proj = layers.Dense(config.n_embd, use_bias=False)
        self.attn_dropout = layers.Dropout(config.dropout)
        self.resid_dropout = layers.Dropout(config.dropout)

        mask = tf.linalg.band_part(
            tf.ones((config.block_size, config.block_size)), -1, 0
        )
        self.causal_mask = tf.reshape(
            mask, (1, 1, config.block_size, config.block_size)
        )

    def call(self, x, training=False):
        batch_size = tf.shape(x)[0]
        seq_len = tf.shape(x)[1]

        qkv = self.qkv(x)
        q, k, v = tf.split(qkv, 3, axis=-1)

        q = tf.reshape(q, [batch_size, seq_len, self.n_head, self.head_size])
        k = tf.reshape(k, [batch_size, seq_len, self.n_head, self.head_size])
        v = tf.reshape(v, [batch_size, seq_len, self.n_head, self.head_size])

        q = tf.transpose(q, [0, 2, 1, 3])
        k = tf.transpose(k, [0, 2, 1, 3])
        v = tf.transpose(v, [0, 2, 1, 3])

        scale = tf.cast(self.head_size, x.dtype) ** -0.5
        scores = tf.matmul(q, k, transpose_b=True) * scale

        mask = self.causal_mask[:, :, :seq_len, :seq_len]
        negative = tf.cast(-1e4, scores.dtype)
        scores = tf.where(mask == 1, scores, negative)

        weights = tf.nn.softmax(scores, axis=-1)
        weights = self.attn_dropout(weights, training=training)

        y = tf.matmul(weights, v)
        y = tf.transpose(y, [0, 2, 1, 3])
        y = tf.reshape(y, [batch_size, seq_len, self.n_embd])

        return self.resid_dropout(self.proj(y), training=training)

class MLP(layers.Layer):
    def __init__(self, config):
        super().__init__()
        self.fc = layers.Dense(4 * config.n_embd)
        self.proj = layers.Dense(config.n_embd)
        self.dropout = layers.Dropout(config.dropout)

    def call(self, x, training=False):
        x = tf.nn.gelu(self.fc(x))
        x = self.proj(x)
        return self.dropout(x, training=training)

class GPTBlock(layers.Layer):
    def __init__(self, config):
        super().__init__()
        self.ln1 = layers.LayerNormalization(epsilon=1e-5)
        self.attention = CausalSelfAttention(config)
        self.ln2 = layers.LayerNormalization(epsilon=1e-5)
        self.mlp = MLP(config)

    def call(self, x, training=False):
        x = x + self.attention(self.ln1(x), training=training)
        x = x + self.mlp(self.ln2(x), training=training)
        return x

class LLigMaGPT(keras.Model):
    def __init__(self, config):
        super().__init__()
        self.config = config

        self.token_embedding = layers.Embedding(
            config.vocab_size, config.n_embd
        )
        self.position_embedding = layers.Embedding(
            config.block_size, config.n_embd
        )
        self.dropout = layers.Dropout(config.dropout)

        self.blocks = [GPTBlock(config) for _ in range(config.n_layer)]
        self.ln_f = layers.LayerNormalization(epsilon=1e-5)
        self.lm_head = layers.Dense(config.vocab_size, use_bias=False)

    def call(self, idx, training=False):
        seq_len = tf.shape(idx)[1]
        positions = tf.range(seq_len)

        x = (
            self.token_embedding(idx)
            + self.position_embedding(positions)
        )

        x = self.dropout(x, training=training)

        for block in self.blocks:
            x = block(x, training=training)

        x = self.ln_f(x)
        return self.lm_head(x)
