from dataclasses import dataclass

@dataclass
class GPTConfig:
    vocab_size: int = 32000
    block_size: int = 256
    n_layer: int = 4
    n_head: int = 4
    n_embd: int = 256
    dropout: float = 0.0
    batch_size: int = 1
    learning_rate: float = 3e-4
    weight_decay: float = 0.1
    grad_clip: float = 1.0
    max_steps: int = 100_000
    checkpoint_interval: int = 1_000

    @property
    def head_size(self):
        if self.n_embd % self.n_head != 0:
            raise ValueError("n_embd must be divisible by n_head")
        return self.n_embd // self.n_head
