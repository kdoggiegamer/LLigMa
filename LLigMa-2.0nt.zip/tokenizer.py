from pathlib import Path
from tokenizers import Tokenizer, models, trainers, pre_tokenizers, decoders


class BPETokenizer:
    def __init__(self, path="data/processed/tokenizer.json"):
        self.path = Path(path)
        self.tokenizer = Tokenizer(models.BPE(unk_token="[UNK]"))
        self.vocab_size = 32000

        if self.path.exists():
            self.tokenizer = Tokenizer.from_file(str(self.path))
            self.vocab_size = self.tokenizer.get_vocab_size()

    def train(self, text_file):
        self.tokenizer.pre_tokenizer = pre_tokenizers.ByteLevel(
            add_prefix_space=False
        )

        trainer = trainers.BpeTrainer(
            vocab_size=32000,
            min_frequency=2,
            special_tokens=["[UNK]", "[BOS]", "[EOS]"],
        )

        self.tokenizer.train([str(text_file)], trainer)

        self.tokenizer.decoder = decoders.ByteLevel()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.tokenizer.save(str(self.path))

        self.vocab_size = self.tokenizer.get_vocab_size()

    def encode(self, text):
        return self.tokenizer.encode(text).ids

    def decode(self, ids):
        return self.tokenizer.decode(ids)
