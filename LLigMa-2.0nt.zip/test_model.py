import tensorflow as tf
from config import GPTConfig
from model import LLigMaGPT

config = GPTConfig()
model = LLigMaGPT(config)

x = tf.random.uniform(
    (1, config.block_size),
    minval=0,
    maxval=config.vocab_size,
    dtype=tf.int32,
)

logits = model(x)

print("\n========== LLigMa 2.0 ==========")
print("Input:      ", x.shape)
print("Output:     ", logits.shape)
print("Parameters: ", f"{model.count_params():,}")
print("GPU:        ", tf.config.list_physical_devices("GPU"))
print("================================\n")
